﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace prog3b_part1_
{
    /// <summary>
    /// Interaction logic for replacing_books.xaml
    /// </summary>
    /// 

    public partial class replacing_books : Window
    {

        //global variables
        // arrays(all kinds)
        DoublyLinkedList<string> books = new DoublyLinkedList<string>();// new instance of that class
       // ArrayList currentBooks= new ArrayList();

        //objects of class
        Stopwatch stopwatch = Stopwatch.StartNew();
        Random rd = new Random();//https://www.tutorialspoint.com/Random-Numbers-in-Chash
        Random random = new Random();
        //UserPoints up = new UserPoints();

        //plain variables
        int bookslength;
        int targetIndex = 0;
        int roundPoints = 0;
        int moves = 0;
        int correctanswerpoints= 0; 
        Boolean clicked = false;


        public replacing_books()
        {// constructor
            InitializeComponent();

            lbtime1.Content = "Time: ";
            lbtAnswersCorrect.Content = "Answers correct: ";
            lbtimePoints.Content = "Time Points: ";
            lbAnswerPoints.Content = "Answer points: ";
            lbMoves.Content = "num of moves:"  ;
            lbMovesPoints.Content="Moves Points";
            lbTotal.Content = "Total Points:" ;

            // UserPoints.Instance.accumulatePoints(10000);
            // MessageBox.Show("" + UserPoints.Instance.getearnedPoints());
            //string workingDirectory = Environment.CurrentDirectory;
            //int direLQenght = (workingDirectory.Length) - 10;
            //string path = workingDirectory.Substring(0, direLQenght) + "/icon/bgsong.mp3";
            //System.Uri uri = new System.Uri(path, UriKind.RelativeOrAbsolute);
            //myMediaElement2.Source = uri;

        }// end

        public void updateListBox()
        {
            // this method is to update the listbox
            // when new book codes have been generated and need to be displayed on the listbox
            // clearing the list box then adding the new book codes

            ListBoxItems.Items.Clear();

            foreach (string item in books)
            {
                ListBoxItems.Items.Add(item);
            }// end for each

        }// end method
      
        public void populate_Books_and_code() 
        { 
            // this method is to populate the book node aswell a the listbox
            /*generating 3 random numbers
             * generation 3 random alphabets
             * ensuring the aphebits are not null
             * ensuring that the letters are in capital
             */

            //variables
            bookslength = books.Count;// assigning the size of the book node so it can be used throughout this class
            //string[] display = new string[bookslength];
            string book_code = "";
            int valuesInBookcode ;
            //int count ; //never used


            for (int i = 0; i < 10; i++)
            {
                valuesInBookcode=0;
                string book = rd.Next(0, 200).ToString();// generating the number code of the books

                if (book.Length == 2)
                {
                    book = "0" + book;
                }
                else
                    if (book.Length == 1)
                {
                    book = "00" + book;
                }
                else
                {
                    while (valuesInBookcode < 3)// generating the book author code
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            book_code = "";
                            int a = random.Next(0, 26);
                            char ch1 = (char)('a' + a);
                            a = random.Next(0, 26);
                            char ch2 = (char)('a' + a);
                            a = random.Next(0, 26);
                            char ch3 = (char)('a' + a);
                            book_code = ch1 + "" + ch2 + "" + ch3;
                            book_code = book_code.ToUpper();
                            valuesInBookcode = book_code.Length;
                        }// END FOR LOOP

                    }// END WHILE
                }
                
                books.Add(book+"_"+book_code);//adding it to the node
               // currentBooks.Add(book);
            }

           
             // populating the listbox
             updateListBox();
            

        }// end method

        public int sortBooks() 
        {
            //variables
            ArrayList books_sorted = new ArrayList();
            string[] usersAnswer = books.ToArray();
            int count = 0;
            int correctAnswers = 0;

            foreach (string item in books)// assigning all the bookcodes in the book node to an arraylist
            { 
                books_sorted.Add(item);

             }// end 

            books_sorted.Sort();// sorting the books in the books_sorted  arraylist

            foreach (string item in books_sorted)
            {

                if (item == usersAnswer[count]) // comparing the book node(users answers) to the sorted books_sorted arratlist
                {
                    correctAnswers ++;// if true then a point is added
                }
                count ++;   // count for the arraylist so it can move to the next value
            }// end foreach


            roundPoints = 0;
            roundPoints = (correctAnswers * 10);


            correctanswerpoints = correctAnswers * 10;
            return correctAnswers;

        }// end 

        public void reset()
        { 
            // used when re setting the game for a new round
            moves = 0;
            books.Clear();
            ListBoxItems.Items.Clear();
            //up.setpoints (0);
            roundPoints = 0;

            lbtime1.Content = "Time: ";
            lbtAnswersCorrect.Content = "Answers correct: ";
            lbtimePoints.Content = "Time Points: ";
            lbAnswerPoints.Content = "Answer points: ";
            lbMoves.Content = "num of moves:";
            lbMovesPoints.Content = "Moves Points: ";
            lbTotal.Content = "Total Points:";
        }// end method

        public void DisplayResults() 
        {
            //used to display the user results


            //variables
            double seconds = stopwatch.Elapsed.TotalSeconds;// timer is stoped
            int an = UserPoints.Instance.MovePoints(moves);

            lbtime1.Content = "Time: " + Math.Round(stopwatch.Elapsed.TotalSeconds) + "s";
            lbtAnswersCorrect.Content = "Answers correct: " + sortBooks() + "/" + books.Count;
            lbtimePoints.Content = "Time Points: " + UserPoints.Instance.timePoints(Math.Round(seconds));
            lbAnswerPoints.Content = "Answer points: " + correctanswerpoints;
            lbMoves.Content = "Num of moves: " + moves;
            lbMovesPoints.Content = "Moves Points: "+ UserPoints.Instance.MovePoints(moves);

            int total = UserPoints.Instance.timePoints(Math.Round(seconds)) + UserPoints.Instance.MovePoints(moves) + correctanswerpoints;
            lbTotal.Content = "Total Points:\t" + total;

            UserPoints.Instance.accumulatePoints(total);

            //MessageBox.Show("" + up.getpoints() + "   " + total);

        }// end method


        //---------------------------------------------------------------------------------------------------

        private void ListBoxItem_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            // what will happen when u click the mouse
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                ListBoxItem draggedItem = sender as ListBoxItem;//dragged item sets the possiblity to drag drop
                if (draggedItem != null)
                {
                    // allow the drag
                    DragDrop.DoDragDrop(draggedItem, draggedItem.Content, DragDropEffects.Move);
                }// end inner if
            }// end outer if
        }//end ListBoxItem_PreviewMouseMove

        private void ListBoxItem_Drop(object sender, DragEventArgs e)
        {
           
            ListBoxItem targetItem = sender as ListBoxItem;
            if (targetItem != null)
            {
                targetIndex= ListBoxItems.Items.IndexOf(targetItem.Content);
                int draggedIndex = books.IndexOf((string)e.Data.GetData(typeof(string)));///////////////
                
                // where it is and where it needs to go 

                if (targetIndex >= 0 && draggedIndex >= 0)
                { //(draggedIndex, targetIndex) 
                  // checking that the data is valid
                  //if not valid will not allow to move
                    books.Move(draggedIndex, targetIndex);
                    moves++;
                    updateListBox();//this is refreshing
                }// end inner if

            }// end if

        }// end ListBoxItem_Drop


        private void btnstart_Click_1(object sender, RoutedEventArgs e)//add 
        {

            if (clicked == false) // the intial click to start game
            {
                stopwatch.Start();// to start the stopwatch

                // the populate the list
                populate_Books_and_code();
               
                clicked = true;

                btnstart.IsEnabled = false;
                btnstart.Visibility = Visibility.Hidden;

            }
            else
            {// this is the second time the user clicks
                
                ListBoxItems.IsEnabled = true;
                
                stopwatch.Restart();// restart stopwatch
                reset();
                // the populate the list
                populate_Books_and_code();
                
                btnstart.IsEnabled = false;
                btnstart.Visibility = Visibility.Hidden;

            }// end if
        }// end start


        private void btncheck_Click(object sender, RoutedEventArgs e)
        {
            //variables
            
            stopwatch.Stop();// to stop stopwatch
            ListBoxItems.IsEnabled = false;
            btnstart.IsEnabled = true;
            btnstart.Visibility = Visibility.Visible;
           // btnstart.Content = "Again";

            if (UserPoints.Instance.protectionOnMoves(moves))
            {
                DisplayResults();
            }// end if


        }// end button check

        private void informationbtn_Click(object sender, RoutedEventArgs e)
        {
            Information_rb irb = new Information_rb();
            irb.Show();

        }// end 

        private void btnlogo2_Click(object sender, RoutedEventArgs e)
        {// hidden game logo 2
            UserPoints.Instance.accumulatePoints(10000);// adding points
            MessageBoxResult result = MessageBox.Show("You have gained 10 000 points,\n", " Logo 1 found",
                   MessageBoxButton.OK, MessageBoxImage.Exclamation);
           // MessageBox.Show(UserPoints.Instance.getpoints()+"");
        }// end

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mx= new MainWindow();
            mx.Show();
            this.Close();
        }
    }// end class

}