﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace prog3b_part1_
{
    public abstract class abstract_class
    {
        private int points;

        public int Points { get => points; set => points = value; }



        protected abstract_class()
        {
           // MessageBox.Show(Points+" is ur points");
                   }

        public int getpoints()
        {
            // to get points from the abstract class
            return Points;
        }// end get points

        public void setpoints(int p)
        {
           // to set points from the abstract class
                Points = p;
        }// end set points

    }
}
