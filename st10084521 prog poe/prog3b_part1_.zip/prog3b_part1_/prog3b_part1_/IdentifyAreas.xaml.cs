﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace prog3b_part1_
{
    /// <summary>
    /// Interaction logic for IdentifyAreas.xaml
    /// </summary>
    public partial class IdentifyAreas : Window
    {
        

        // global variables
        DispatcherTimer dt = new DispatcherTimer();
        private MediaPlayer mediaPlayer = new MediaPlayer();
        // timer increment variables
        private int increment = 0;
        private int correct_answer = 0;
        private int totatalPoints = 0;
        private int moves = 0;
        private int timepoints = 0;

        // method to place timer in label
        private void Dt_Tick(object sender, EventArgs e)
        {
            increment++;

            timerLbl.Content = increment.ToString();
        }

        public IdentifyAreas()
        {
            InitializeComponent();


                // startBtn.Content = "Start";
                // startBtn.Visibility = Visibility.Hidden;
                firstLevelList.Visibility = Visibility.Visible;
                firstLevelList.IsEnabled = true;
                firstNext.Visibility = Visibility.Visible;
                secondLevelList.Visibility = Visibility.Hidden;
                secondLevelList.Visibility = Visibility.Hidden;
                secondNext.Visibility = Visibility.Hidden;
                thirdLevelList.Visibility = Visibility.Hidden;
                //submitBtn.Visibility = Visibility.Hidden;

                Callnumber.LoadCallNumbers();

                // load the quiz goal that the user must get to
                answerLbl.Content = Callnumber.myGoal;

                // prepare lists to add quiz options to ui for the user to select
                thirdLevelList.Items.Clear();
                secondLevelList.Items.Clear();
                firstLevelList.Items.Clear();

                foreach (string i in Callnumber.firstLevelChoice)
                {
                    firstLevelList.Items.Add(i);
                }

                foreach (string i in Callnumber.secondLevelChoice)
                {
                    secondLevelList.Items.Add(i);
                }

                foreach (string i in Callnumber.thirdLevelChoice)
                {
                    thirdLevelList.Items.Add(i);
                }

                // creating timer to start on button click
                dt.Interval = TimeSpan.FromSeconds(1);
                dt.Tick += Dt_Tick;
                dt.Start();

                RedoBtn.Visibility = Visibility.Hidden;
                RedoBtn.IsEnabled = false;

                thirdNext.Visibility = Visibility.Hidden;
                thirdNext.IsEnabled = false;

            lbltime.Content = "";
            lbltotalp.Content = "";
            lblcp.Content = "";
            lblTimep.Content = "";
            lblmoves.Content = "";
            lblmovesp.Content = "";


        }

        private void firstNext_Click(object sender, RoutedEventArgs e)
        {
            moves++;
            // error message if user selects nothing
            if (firstLevelList.SelectedItem == null)
            {
                MessageBox.Show("Please select an item");
            }
            else
            {
                // check users answer
                if (firstLevelList.SelectedItem.Equals(Callnumber.firstLevelAnswer))
                {
                    // give random positive feedback to user
                    Random rand = new Random(Guid.NewGuid().GetHashCode());
                    var corResponses = new List<string> { "Well done, that is correct!", "Wow, that's correcr", "Nice work! You got all right" };
                    int choice = rand.Next(corResponses.Count);
                    MessageBox.Show(corResponses[choice]);
                    // show next phase of game
                    firstLevelList.IsEnabled = true;
                    firstNext.Visibility = Visibility.Hidden;
                    secondLevelList.Visibility = Visibility.Visible;
                    secondLevelList.IsEnabled = true;
                    secondNext.Visibility = Visibility.Visible;
                    correct_answer++;

                }
                else
                {
                    // negative random feedback for wrong answer
                    Random rand = new Random(Guid.NewGuid().GetHashCode());
                    var wrongResponses = new List<string> { "You trash", "Get a life loser", "Your skills are obsolete" };
                    int choice = rand.Next(wrongResponses.Count);
                    MessageBox.Show(wrongResponses[choice]);

                    // game starts again
                    // startBtn.Visibility = Visibility.Hidden;
                    //  startBtn.FontSize = 20;
                    //  startBtn.Content = "Try Again";
                }
            }
        }

        private void secondNext_Click(object sender, RoutedEventArgs e)
        {
            moves++;
            //Error message if user selects nothing
            if (secondLevelList.SelectedItem == null)
            {
                MessageBox.Show("Ahh a trickster, You must choose if you want Glory.");
            }
            else
            {
                //Check user answer
                if (secondLevelList.SelectedItem.Equals(Callnumber.secondLevelAnswer))
                {
                    //Give Random positive feeback to user
                    Random rand = new Random(Guid.NewGuid().GetHashCode());
                    var corResponses = new List<string> { "Well Done, that is correct!", "Wow, one step closer to victory. Well Done!", "Spot on! You made that look easy." };
                    int choice = rand.Next(corResponses.Count);
                    MessageBox.Show(corResponses[choice]);
                    correct_answer++;
                    //Show next phase of game
                    //secondLevelList.IsEnabled = false;
                    //secondNext.Visibility = Visibility.Hidden;
                    secondNext.Visibility = Visibility.Hidden;

                    thirdLevelList.Visibility = Visibility.Visible;
                    thirdLevelList.IsEnabled = true;
                    //submitBtn.Visibility = Visibility.Visible;
                    thirdNext.Visibility = Visibility.Visible;
                    thirdNext.IsEnabled = true;

                }
                else
                {
                    //Random Negative feedback for wrong answer
                    Random rand = new Random(Guid.NewGuid().GetHashCode());
                    var wroResponses = new List<string> { "That is incorrect!", "Wow, I thought you had it. Wrong!", "So close, but you have chosen wrong." };
                    int choice = rand.Next(wroResponses.Count);
                    MessageBox.Show(wroResponses[choice]);

                    //Game starts again
                    // startBtn.Visibility = Visibility.Visible;
                    //startBtn.FontSize = 20;
                    //startBtn.Content = "Try Again!";

                }// end inside if

            }// end outside if
        }// end second

        private void thirdNext_Click(object sender, RoutedEventArgs e)
        {
            moves++;
            // error message if user selects nothing
            if (thirdLevelList.SelectedItem == null)
            {
                MessageBox.Show("Please select an item");
            }
            else
            {
                // check users answer
                if (thirdLevelList.SelectedItem.Equals(Callnumber.thirdLevelAnswer))
                {
                    // give random positive feedback to user
                    Random rand = new Random(Guid.NewGuid().GetHashCode());
                    var corResponses = new List<string> { "Well done, that is correct!", "Wow, that's correcr", "Nice work! You got all right" };
                    int choice = rand.Next(corResponses.Count);
                    MessageBox.Show(corResponses[choice]);

                    // MessageBox.Show("you finished");
                    // show next phase of game
                    thirdLevelList.IsEnabled = true;
                    thirdNext.Visibility = Visibility.Hidden;
                    // secondLevelList.Visibility = Visibility.Visible;
                    //secondLevelList.IsEnabled = true;
                    // secondNext.Visibility = Visibility.Visible;
                    RedoBtn.Visibility = Visibility.Visible;
                    RedoBtn.IsEnabled = true;

                    // timer 
                    dt.Stop();
                    lbltime.Content = increment.ToString();
                   timepoints= UserPoints.Instance.IAtimePoints(increment);
                    lblTimep.Content = timepoints.ToString();

                    // correct answers
                    lblcp.Content = "30 points";

                    // moves
                    lblmoves.Content = moves;
                    lblmovesp.Content = movepoints(moves).ToString();

                    // total points
                    totatalPoints += (30 + movepoints(moves) + timepoints);
                    lbltotalp.Content = totatalPoints.ToString();
                    UserPoints.Instance.accumulatePoints((30 + movepoints(moves) + timepoints));
                }
                else
                {
                    // negative random feedback for wrong answer
                    Random rand = new Random(Guid.NewGuid().GetHashCode());
                    var wrongResponses = new List<string> { "You trash", "Get a life loser", "Your skills are obsolete" };
                    int choice = rand.Next(wrongResponses.Count);
                    MessageBox.Show(wrongResponses[choice]);
                    // MessageBox.Show(thirdLevelList.SelectedItem.ToString() + "\n"+Callnumber.thirdLevelAnswer+"\n"+Callnumber.thirdLevelChoice.ToString());

                    //Game starts again
                    //startBtn.Visibility = Visibility.Visible;
                    // startBtn.FontSize = 20;
                    // startBtn.Content = "Try Again!";

                }
            }
        }// not done

        private void infoBtn_Click(object sender, RoutedEventArgs e)// not done
        {
            info_IA iainfo = new info_IA();
            iainfo.Show();
        }

        private void RedoBtn_Click(object sender, RoutedEventArgs e)
        {
            // startBtn.Content = "Start";
            // startBtn.Visibility = Visibility.Hidden;
            firstLevelList.Visibility = Visibility.Visible;
            firstLevelList.IsEnabled = true;
            firstNext.Visibility = Visibility.Visible;
            secondLevelList.Visibility = Visibility.Hidden;
            secondLevelList.Visibility = Visibility.Hidden;
            secondNext.Visibility = Visibility.Hidden;
            thirdLevelList.Visibility = Visibility.Hidden;
            //submitBtn.Visibility = Visibility.Hidden;

            Callnumber.LoadCallNumbers();

            // load the quiz goal that the user must get to
            answerLbl.Content = Callnumber.myGoal;

            // prepare lists to add quiz options to ui for the user to select
            thirdLevelList.Items.Clear();
            secondLevelList.Items.Clear();
            firstLevelList.Items.Clear();

            foreach (string i in Callnumber.firstLevelChoice)
            {
                firstLevelList.Items.Add(i);
            }

            foreach (string i in Callnumber.secondLevelChoice)
            {
                secondLevelList.Items.Add(i);
            }

            foreach (string i in Callnumber.thirdLevelChoice)
            {
                thirdLevelList.Items.Add(i);
            }

            // creating timer to start on button click
            increment = 0;
            dt.Interval = TimeSpan.FromSeconds(1);
            //dt.Tick += Dt_Tick;
            dt.Start();

            RedoBtn.Visibility = Visibility.Hidden;
            RedoBtn.IsEnabled = false;

            moves = 0;
            timepoints = 0;
        }

        private static int movepoints(int moves)
        {
            int points = 0;

            if (moves == 3)
            {
                points = 100;
            }
            else if (moves == 4)
            {
                points = 90;
            }
            else if (moves == 5)
            {
                points = 80;
            }
            else
                if (moves == 6 || moves == 7)
            {
                points = 60;
            }
            else
                if (moves == 8 || moves == 9)
            {
                points = 40;
            }

            return points;

        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mx = new MainWindow();
            mx.Show();
            this.Close();
        }

        private void Hiddenlogo4Btn_Click(object sender, RoutedEventArgs e)
        {
            // up.accumulatePoints(10000);
            UserPoints.Instance.accumulatePoints(10000);
            MessageBoxResult result = MessageBox.Show("You have gained 10 000 points,\n", " Logo 4 found",
                   MessageBoxButton.OK, MessageBoxImage.Asterisk);
        }
    }// end class
}//end
