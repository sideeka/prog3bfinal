﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace prog3b_part1_
{
     public class UserPoints : abstract_class
    {// this class is an extension of the abstract class

        private int earnedPoints ;
        private static UserPoints instance; // Singleton instance

        public int EarnedPoints { get => earnedPoints; set => earnedPoints = value; }

        public static UserPoints Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new UserPoints();
                }
                return instance;
            }
        }

        private UserPoints()
        {
            // Private constructor to prevent external instantiation.
            this.earnedPoints = 0;
        }

        public int getearnedPoints()
        {
            return earnedPoints;
        }

        public void setearnedPoints(int po)
        {
            earnedPoints = po;
        }

        public void accumulatePoints(int newp)
        {
            EarnedPoints += newp;
           setpoints(earnedPoints);
        }// end accumulate

        public int timePoints(double time)
        {// this method is to determine what points the user should
         // achive based on the amount o ftime it took them to sort
         // the list of book codes
            
            //variables
            int tp = 0;// short for time points


            /* an if statement that assigns a certain amount of points to the user based on the amount of seconds it took to sort.
             *There is ranges for the point.
             *The shorter the time the larger amount of points */

            if (time < 25 && time > 20)
            {
                tp = 300;
            }
            else if (time >= 25 && time < 30)
            {
                tp = 250;
            }
            else if (time >= 30 && time < 45)
            {
                tp = 200;
            }
            else if (time == 45)
            {
                tp = 150;
            }
            else
             if (time > 45)
            {
                tp = 100;
            }

            accumulatePoints(tp);// pulling the method from this class to add to the point in the abstarct class
            return tp;
        }// end time points method

        public int IAtimePoints(double time)
        {// this method is to determine what points the user should
         // achive based on the amount o ftime it took them to sort
         // the list of book codes

            //variables
            int tp = 0;// short for time points


            /* an if statement that assigns a certain amount of points to the user based on the amount of seconds it took to sort.
             *There is ranges for the point.
             *The shorter the time the larger amount of points */

            if (time >=6 && time <=12)
            {
                tp = 300;
            }
            else if (time >= 13 && time < 23)
            {
                tp = 250;
            }
            else if (time >= 24 && time < 34)
            {
                tp = 200;
            }
            else
             if (time > 35)
            {
                tp = 100;
            }

            //accumulatePoints(tp);// pulling the method from this class to add to the point in the abstarct class
            return tp;
        }// end time points method

        public int MovePoints(int moves)
        {
            // this method is to determine what points the user should
             // achive based on the amount number of moves it took them to sort
             // the list of book codes
             //the moves are a parameter 

                //variables
                int mp = 0;// short for moves points

            /* an if statement that assigns a certain amount of points to the user based on the amount of moves it took to sort.
             *there is a strict points system compared to the timePoints(). no ranges
             *The less num moves the larger amount of points.
             *If the user finished it in less than 5 moves that means they either:
             * *did not play the game properly
             * *didnt play the game at all
             * * the codes generated were not challenging
             *   and so they will earn a small number of points
             */


            if (moves < 5) 
            {
                mp = 350;
            }
            else
            {
                // switch case statement to assign the amounts basexd on the number moves taken as a parameter
                switch (moves)
                {
                    case 5:
                        mp = 300;
                        break;
                    case 6:
                        mp = 280;
                        break;
                    case 7:
                        mp = 260;
                        break;
                    case 8:
                        mp = 240;
                        break;
                    case 9:
                        mp = 220;
                        break;
                    case 10:
                        mp = 200;
                        break;
                    case 11:
                        mp = 180;
                        break;
                    case 12:
                        mp = 160;
                        break;
                    default:
                        mp = 50;
                        break;
                }//end switch
            }// end if

            accumulatePoints(mp);// pulling the method from this class to add to the point in the abstarct class
            return mp;
        }// end move points

        public bool protectionOnMoves(int moves)
        {
            // this is to ensure that the user has played the game
            // if the number of moves(parameter) is less than 5 which is the minimum amount of moves
            // to complete the sorting they will be promted and asked if they are sure they have done the sorting.
           // if yes they can continue counting their points.
           // If not they have to start again

            // this method retruns the answer in the form of boolean

            
            // avriabes
            Boolean ActuallyAnswered = false;// using a boolean to check hwether moves are above 5

            if (moves > 5)// if yes then the second if statement will not occur
            {
                ActuallyAnswered = true;
            }

            if (moves == 0 && ActuallyAnswered == false)
            {
                //this means the user has never played the game at all
                MessageBoxResult result = MessageBox.Show("You have not played the game ,\n", "Moves error",
                    MessageBoxButton.OK, MessageBoxImage.Error);

            }
            else if ((moves < 5 && moves != 0) && ActuallyAnswered == false)
            {

                //To check if they have played
                MessageBoxResult result = MessageBox.Show("You have used less than the expected moves of a normal game," +
                    "\n Please ignore this message if u have managed to sort in less than 5 moves by pressing yes", "Moves error",
                    MessageBoxButton.YesNo, MessageBoxImage.Error);

                if (result == MessageBoxResult.Yes)
                {
                    ActuallyAnswered = true;
                    // the points will be counted in the method in wwhich this method is called(btn check)

                }
                else if (result == MessageBoxResult.No)
                {
                    // they havent played the game and will start again
                    MessageBox.Show("Sorry but u will need to start again", "Moves error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }//end if



            return ActuallyAnswered;
        }// end method


    }
}
