﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace prog3b_part1_
{
    public class Callnumber
    {
        // lists for each level
        public static List<string> thirdLevel = new List<string>();
        public static List<string> secondLevel = new List<string>();
        public static List<string> firstLevel = new List<string>();

        // variable that is used to track answers --> for checking
        public static string myAnswer = "";
        public static string myGoal = "";
        public static string finalLevelAnswer = "";

        // list to store options that the user can use 
        public static List<string> thirdLevelChoice = new List<string>();
        public static List<string> secondLevelChoice = new List<string>();
        public static List<string> firstLevelChoice = new List<string>();

        // tracking input 
        public static string thirdLevelAnswer = "";
        public static string thirdLevelAnswerFull = "";// added
        public static string secondLevelAnswer = "";
        public static string firstLevelAnswer = "";

        // for randomizing lists
        public static Random random = new Random();

        // get the text file 
        public static void LoadCallNumbers()
        {
            //https://it-delinquent.medium.com/playing-multiple-sounds-in-wpf-application-b14251eb5408// for media
            //https://stackoverflow.com/questions/31147049/how-do-i-convert-a-string-to-a-system-uri// to create a uri
            //https://stackoverflow.com/questions/15653921/get-current-folder-path// current directory
            string workingDirectory = Environment.CurrentDirectory;
            // string myPath = @"C:\Users\sidee\OneDrive\Desktop\callnumbers.txt";

            string myPath = workingDirectory + @"\callnumbers.txt"; ;
            string[] textFile;

            // check if it exists
            if (!File.Exists(myPath))
            {
                MessageBox.Show("Call numbers - loading error");
            }
            else
            {
                //MessageBox.Show("worked");
                // read from the file 
                textFile = File.ReadAllLines(myPath);
                // ready to parse text file into the tree
                string totalTree = "";
                // iterate through the file -> for each string character in the text file -> concat
                foreach (string character in textFile)
                {
                    totalTree += character;
                }
                TreeNode tree = TreeNode.BuildTree(textFile);
                // space for random generation and scrambling
                SelectRandomAnswer(tree);
                // obscure the answer by removing call num
                myGoal = thirdLevelAnswerFull.Substring(4, thirdLevelAnswerFull.Length - 4);//added
            }// end file exist
        }// end 

        // method to select random answer
        private static void SelectRandomAnswer(TreeNode tree)
        {
            firstLevel.Clear();
            secondLevel.Clear();
            thirdLevel.Clear();

            foreach (TreeNode tree1 in tree)
            {
                firstLevel.Add(tree1.ID);
                foreach (TreeNode tree2 in tree1)
                {
                    secondLevel.Add(tree2.ID);
                    foreach (TreeNode tree3 in tree2)
                    {
                        thirdLevel.Add(tree3.ID);
                    }// end 3 foreach
                }// end 2 foreach
            }// end 1 foreach

            firstLevelChoice.Clear();
            secondLevelChoice.Clear();
            thirdLevelChoice.Clear();

            //************************************************************************************************

            //Randomly choose first level answer
            int choice = random.Next(firstLevel.Count());
            firstLevelAnswer = firstLevel[choice];
            firstLevelChoice.Add(firstLevelAnswer);

            //Add random first level wrong options
            for (int i = 0; i < 3; i++)
            {
                Random theRand = new Random(Guid.NewGuid().GetHashCode());
                int randomChoice = theRand.Next(firstLevel.Count);

                if (!firstLevel[randomChoice].Equals(firstLevelAnswer) && !firstLevelChoice.Contains(firstLevel[randomChoice]))
                {
                    firstLevelChoice.Add(firstLevel[randomChoice]);
                }
                else
                {
                    i--;

                }// end if 

            }// end for each
            //************************************************************************************************

            //###################################################################################################
            //Randomly choose second level answer
            for (int i = 0; i < 1; i++)
            {
                Random theRand = new Random(Guid.NewGuid().GetHashCode());
                choice = theRand.Next(secondLevel.Count);

                if (secondLevel[choice].StartsWith(firstLevelAnswer.Substring(0, 1)))
                {
                    secondLevelAnswer = secondLevel[choice];
                    secondLevelChoice.Add(secondLevelAnswer);
                }
                else
                {
                    i--;
                }// end if 
            }// end foreach

            //Add random second level wrong options
            for (int i = 0; i < 3; i++)
            {
                Random theRand = new Random(Guid.NewGuid().GetHashCode());
                int randomChoice = theRand.Next(secondLevel.Count);

                if (secondLevel[randomChoice].StartsWith(firstLevelAnswer.Substring(0, 1))
                    && !secondLevel[randomChoice].Equals(secondLevelAnswer) &&
                    !secondLevelChoice.Contains(secondLevel[randomChoice]))
                {
                    secondLevelChoice.Add(secondLevel[randomChoice]);
                }

                else
                {
                    i--;
                }
            }

            //###################################################################################################

            //Randomly choose third level answer
            for (int i = 0; i < 1; i++)
            {
                Random theRand = new Random(Guid.NewGuid().GetHashCode());
                choice = theRand.Next(thirdLevel.Count);
                if (thirdLevel[choice].StartsWith(secondLevelAnswer.Substring(0, 2)))
                {
                    thirdLevelAnswer = thirdLevel[choice];
                    thirdLevelAnswerFull = thirdLevel[choice];
                    thirdLevelChoice.Add(thirdLevelAnswer);
                    thirdLevelAnswer = thirdLevel[choice].Substring(0, 3);
                    //MessageBox.Show("answer     " + thirdLevelAnswer);
                }
                else
                {
                    i--;
                }// end if

            }// end for each 


            //Add random third level wrong options
            for (int i = 0; i < 3; i++)
            {
                Random theRand = new Random(Guid.NewGuid().GetHashCode());
                int randomChoice = theRand.Next(8) + 1;
                string wrongChoice = secondLevelAnswer.Substring(0, 2) + randomChoice;

                if (!wrongChoice.Equals(thirdLevelAnswer.Substring(0, 3)) &&
                    !thirdLevelChoice.Contains(wrongChoice))
                {
                    thirdLevelChoice.Add(wrongChoice);
                }
                else
                {
                    i--;

                }
            }

            //Change the format of all third level answers to consistent format
            for (int i = 0; i < thirdLevelChoice.Count; i++)
            {
                thirdLevelChoice[i] = thirdLevelChoice[i].Substring(0, 3);

            }
            //Sort the lists numerically

            firstLevelChoice.Sort();
            secondLevelChoice.Sort();
            thirdLevelChoice.Sort();

        }
    }// end class call number

    public class TreeNode : IEnumerable<TreeNode>
    {

        //variables
        private readonly Dictionary<string, TreeNode> _children = new Dictionary<string, TreeNode>();

        public readonly string ID;

        public TreeNode Parent { get; private set; }

        public TreeNode(string id)
        {
            this.ID = id;
        }

        public TreeNode GetChild(string id)
        {
            return this._children[id];
        }


        public void Add(TreeNode item)
        {
            if (item.Parent != null)
            {
                item.Parent._children.Remove(item.ID);
            }
            item.Parent = this;
            this._children.Add(item.ID, item);
        }

        public int Count
        {
            get { return this._children.Count; }
        }

        public static TreeNode BuildTree(string[] tree)
        {
            var result = new TreeNode("TreeRoot");
            var list = new List<TreeNode> { result };

            foreach (var line in tree)
            {
                var trimmedLine = line.Trim();

                var indent = line.Length - trimmedLine.Length;

                var child = new TreeNode(trimmedLine);
                list[indent].Add(child);//////////////////////////////////////////////////////////////////////

                if (indent + 1 < list.Count)
                {
                    list[indent + 1] = child;
                }
                else
                {
                    list.Add(child);
                }

            }
            return result;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }


        public IEnumerator<TreeNode> GetEnumerator()
        {
            return this._children.Values.GetEnumerator();
        }
    }// end class treenode

}// end 
