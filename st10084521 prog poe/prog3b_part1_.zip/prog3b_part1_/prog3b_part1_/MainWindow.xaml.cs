﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace prog3b_part1_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //gloabl objects
        // UserPoints up = new UserPoints();


        public MainWindow()
        {
            InitializeComponent();

            /* how i was playing the music
            //https://it-delinquent.medium.com/playing-multiple-sounds-in-wpf-application-b14251eb5408// for media
            //https://stackoverflow.com/questions/31147049/how-do-i-convert-a-string-to-a-system-uri// to create a uri
            //https://stackoverflow.com/questions/15653921/get-current-folder-path// current directory
            string workingDirectory = Environment.CurrentDirectory;
            int direLQenght = (workingDirectory.Length)-10;
            string path = workingDirectory.Substring(0, direLQenght) + "/icon/bgsong.mp3";
            System.Uri uri = new System.Uri(path, UriKind.RelativeOrAbsolute);
            myMediaElement1.Source = uri;
            */

            // to play bakgrund music throughout the application
            SoundPlayer backgroundMusic = new SoundPlayer("bgsong.wav");

            //Play song looping
            backgroundMusic.LoadCompleted += delegate (object sender, AsyncCompletedEventArgs e) {
                backgroundMusic.PlayLooping();
            };
            backgroundMusic.LoadAsync();
        }// end cnstructor

        private void Button_Click(object sender, RoutedEventArgs e)// replace books bt
        {
            replacing_books rb= new replacing_books();
            rb.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)// call numbers btn
        {
            call_numbers cn = new call_numbers();
            cn.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)// identify area
        {
            IdentifyAreas ia = new IdentifyAreas();
            ia.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void logogame_Click(object sender, RoutedEventArgs e)
        {
            secret_game sg= new secret_game();
            sg.Show();
        }

        private void btnlogo1_Click(object sender, RoutedEventArgs e)
        {
            // up.accumulatePoints(10000);
            UserPoints.Instance.accumulatePoints(10000);
            MessageBoxResult result = MessageBox.Show("You have gained 10 000 points,\n", " Logo 1 found",
                   MessageBoxButton.OK, MessageBoxImage.Asterisk);
        }

        private void btnUserpoints_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("You have:  "+UserPoints.Instance.getearnedPoints()+" points", " Your points",
                   MessageBoxButton.OK, MessageBoxImage.Asterisk);
        }
    }
}
