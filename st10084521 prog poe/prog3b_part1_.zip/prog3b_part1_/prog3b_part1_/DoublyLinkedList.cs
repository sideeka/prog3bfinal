﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog3b_part1_
{
   
        public class DoublyLinkedList<T> : IEnumerable<T>// generic
        {
            //doubly linked list have to have a node class
            public class Node
            {
                //used cont when cretaing a new container on the train
                public T Value { get; set; }
                public Node Next { get; set; }
                public Node Prev { get; set; }
            }

            // only declared once
            public Node head;
            public Node tail;


            public void Add(T value)
            {
                Node newnode = new Node { Value = value };
                if (head == null)
                {
                    head = newnode;
                    tail = newnode;
                }
                else
                {
                    tail.Next = newnode;
                    newnode.Prev = tail;
                    tail = newnode;
                }

            }


            public IEnumerator<T> GetEnumerator()
            {
                // throw new NotImplementedException();
                Node current = head;
                while (current != null)// checking if the head is emty or not
                {
                    // if not emty then interation can occur
                    yield return current.Value;
                    current = current.Next;
                }

            }

            IEnumerator IEnumerable.GetEnumerator()//non generic
            {// provides compatibility for any non generics iteration scenarios
                return ((IEnumerable<T>)this).GetEnumerator();
            }

      
            public int IndexOf(T value)// keeping track
            {
                //throw new NotImplementedException();
                Node current = head;
                int index = 0;
                while (current != null)
                {
                    // needs to compare the 2
                    if (EqualityComparer<T>.Default.Equals(current.Value, value))
                        // comparing the current value to the value u are looking to replace 
                        return index;
                    index++;
                    current = current.Next;
                }
                return -1;// this indicates that the value has not been found
            }// end indexof

            public void Move(int sourceIndex, int destinationIndex)
            {
                //checks while you move things around in this list?
                if (sourceIndex < 0 || sourceIndex >= Count || destinationIndex < 0 || destinationIndex > Count)
                    return;

                Node sourceNode = GetNodeAtIndex(sourceIndex);
                Node destNode = GetNodeAtIndex(destinationIndex);


                T temp = sourceNode.Value;
                sourceNode.Value = destNode.Value;
                destNode.Value = temp;

            }// end move

            private Node GetNodeAtIndex(int Index)
            {
                //  throw new NotImplementedException();

                // right click and choose generate method above
                // remove the trows exception
                Node current = head;
                for (int i = 0; i < Index && current != null; i++)
                {
                    current = current.Next; // will move onto the next node
                }
                return current;
            }//GetNodeAtIndex

            public int Count
            {
                get
                {
                    int count = 0;
                    Node current = head;// start of the linked  list
                    while (current != null)
                    {
                        count++;
                        current = current.Next;
                    }
                    return count;
                }
            }// end count

        public void Clear()
        {
            Node current = head;
            while (current != null)
            {
                Node next = current.Next;
                current = null;
                current = next;
            }

            head = null;
            tail = null;
        }


    }

}
