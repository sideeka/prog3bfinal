﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Media;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace prog3b_part1_
{
    /// <summary>
    /// Interaction logic for call_numbers.xaml
    /// </summary>
    public partial class call_numbers : Window
    {
        //global

        // variables
        public static int qCount = 4;
        public static bool callQ = true;
        public static int myScore;
        public static int maxScore;
        public static int totalSCORE = 0;
        public static int movescount;

        //objects
        Random rand = new Random();
        Stopwatch stopwatch = Stopwatch.StartNew();
        IDictionary<string, string> baseQuestions = new Dictionary<string, string>();
        IDictionary<string, string> usedQuestions = new Dictionary<string, string>();

        public call_numbers()
        {
            InitializeComponent();

            loadDefaults();
            repopulateLists();
            //btns enabled
            stopwatch.Start();
            btnUp.IsEnabled = true;
            btnDown.IsEnabled = true;
            
            
            //string workingDirectory = Environment.CurrentDirectory;
            //int direLQenght = (workingDirectory.Length) - 10;
            //string path = workingDirectory.Substring(0, direLQenght) + "/icon/bgsong.mp3";
            //System.Uri uri = new System.Uri(path, UriKind.RelativeOrAbsolute);
            //myMediaElement.Source = uri;

        }// constructor

        #region adding of data to the dictionary
        private void loadDefaults()
        {
            txtcurrentscore.Text="";
            txtTime.Text = "";
            txtTimescore.Text = "";
            txtTotalscore.Text = "";

            baseQuestions.Clear();
            usedQuestions.Clear();
            //list of possible questions
            baseQuestions.Add("000-099", "General Works");
            baseQuestions.Add("100-199", "Philosophy and Psychology");
            baseQuestions.Add("200-299", "Religion");
            baseQuestions.Add("300-399", "Social Sciences");
            baseQuestions.Add("400-499", "Language");
            baseQuestions.Add("500-599", "Natural Sciences and Mathematics");
            baseQuestions.Add("600-699", "Technology");
            baseQuestions.Add("700-799", "The Arts");
            baseQuestions.Add("800-899", "Literature and Rhetoric");
            baseQuestions.Add("900-999", "History, Biology, and Geography");
        }
        #endregion

       
        internal static void findChildren<T>(List<T> results, DependencyObject startNode)
            where T : DependencyObject
        {
            int count = VisualTreeHelper.GetChildrenCount(startNode);

            for (int i = 0; i < count; i++)
            {
                DependencyObject current = VisualTreeHelper.GetChild(startNode, i);
                if ((current.GetType()).Equals(typeof(T)) ||
                    (current.GetType()).GetTypeInfo().IsSubclassOf(typeof(T)))
                {
                    T asType = (T)current;
                    results.Add(asType);
                }
                findChildren<T>(results, current);
            }

        }


        #region to find answers and calculate score
        //method to calculate score
        private int CalcScore()
        {
            int score = 0;
            List<ListBoxItem> list = new List<ListBoxItem>();
            findChildren(list, listAnswers);
            for (int i = 0; i < qCount; i++)
            {
                string callNumber;
                string description;
                if (!callQ)
                {
                    callNumber = listQuestions.Items[i].ToString();
                    description = listAnswers.Items[i].ToString();
                }
                else
                {
                    callNumber = listAnswers.Items[i].ToString();
                    description = listQuestions.Items[i].ToString();
                }
                // Now deal with the used questions and unused answers
                if (usedQuestions.ContainsKey(callNumber) && usedQuestions[callNumber] == description)
                {
                    // Pick a color to light them up
                    list[i].Background = new SolidColorBrush(Colors.Green);

                    score++;
                    //BadgeImage.Visibility = Visibility.Visible;
                }
                else
                {
                    list[i].Background = new SolidColorBrush(Colors.Red);


                }
            }
            for (int i = qCount; i < listAnswers.Items.Count; i++)
            {
                list[i].Background = new SolidColorBrush(Colors.PaleVioletRed);
            }
            return score;
        }
        #endregion

        //Dictgionary --> kvp --> method
        private void getKVP(out string call, out string desc)
        {
            KeyValuePair<string, string> kvp;
            int index = rand.Next(baseQuestions.Count());
            kvp = baseQuestions.ElementAt(index);
            usedQuestions.Add(kvp);
            baseQuestions.Remove(kvp);
            call = kvp.Key;
            desc = kvp.Value;
        }

        #region for when redo button
        private void repopulateLists()
        {
            listAnswers.IsEnabled = true;
            listQuestions.Items.Clear();
            listAnswers.Items.Clear();
            //alt between call numbers and descriptions
            if (callQ)
            {
                //generate 4 callNo + 4 DEscriptions
                for (int i = 0; i < 4; i++)
                {
                    getKVP(out string callNo, out string desc);
                    listQuestions.Items.Add(callNo);
                    listAnswers.Items.Add(desc);
                }
                //generate 3 morre desc
                for (int i = 0; i < 3; i++)
                {
                    getKVP(out _, out string desc);
                    listAnswers.Items.Add(desc);
                }
                //Prep alt
                callQ = false;
            }
            else
            {
                //generate 4 callNo + 4 DEscriptions
                for (int i = 0; i < 4; i++)
                {
                    getKVP(out string callNo, out string desc);
                    listQuestions.Items.Add(desc);
                    listAnswers.Items.Add(callNo);
                }
                //generate 3 morre desc
                for (int i = 0; i < 3; i++)
                {
                    getKVP(out string callNo, out _);
                    listAnswers.Items.Add(callNo);
                }
                //Prep alt
                callQ = true;
            }
            //TODO shuffle lists
            controls_class.randomizeList(listQuestions);
            controls_class.randomizeList(listAnswers);
        }
        #endregion

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            controls_class.SwapIndexes(+1, listAnswers);
            movescount++;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            controls_class.SwapIndexes(-1, listAnswers);
            //can pull recolor option here
            movescount++;

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)// submit
        {
            // submits answersz to be checked
            // pull the method - setup the textblocks
            // and gamification features -- if you need to
            int score = CalcScore();
            int time = 0;
           int timePoints = 0;

            btnUp.IsEnabled = false;
            btnDown.IsEnabled = false;
            listAnswers.IsEnabled = false;

            //load the defaults
            loadDefaults();
            if (UserPoints.Instance.protectionOnMoves(movescount))
            { 
            stopwatch.Stop();

            myScore = myScore + score;
            maxScore = maxScore + qCount;

            totalSCORE += score;
            txtcurrentscore.Text = $" {myScore}/4";
            txtTotalscore.Text = $" {totalSCORE}/{maxScore}";
            time= (int)Math.Round(stopwatch.Elapsed.TotalSeconds);
            txtTime.Text = time+ "s";
            timePoints= UserPoints.Instance.timePoints(time);
            txtTimescore.Text = timePoints.ToString();
             
            UserPoints.Instance.accumulatePoints((myScore));
            }

        }// submitt

        private void Button_Click_4(object sender, RoutedEventArgs e)// new game
        {
            if (btnSubmit.IsEnabled == true)
            {
                MessageBoxResult dialogueResult = MessageBox.Show("Are you sure you want to start a new game? " +
                    "This will reset your score", "New game", MessageBoxButton.YesNo);
                if (dialogueResult == MessageBoxResult.Yes)
                {
                    myScore = 0;
                   // maxScore = 0;
                    txtcurrentscore.Text = "";
                    txtTotalscore.Text = "";
                    txtTime.Text = "";
                    movescount = 0;

                }
                else
                {
                    return;
                }
            }
            loadDefaults();
            repopulateLists();
            btnUp.IsEnabled = true;
            btnDown.IsEnabled = true;
            stopwatch.Restart();
        }// new game

        private void Button_Click_3(object sender, RoutedEventArgs e)//back
        {
            MainWindow mw = new MainWindow();
           mw.Show();
            this.Close(); // This code closes the current window.
        }// end back btn

        private void btnexplaincallnumber_Click(object sender, RoutedEventArgs e)
        {// to display the page to explain how to use the prgram
            explainCallNumber ecn = new explainCallNumber();
            ecn.Show();

        }

        private void btnlogo3_Click(object sender, RoutedEventArgs e)
        {
            UserPoints.Instance.accumulatePoints(10000);
            MessageBoxResult result = MessageBox.Show("You have gained 10 000 points,\n", " Logo 1 found",
                  MessageBoxButton.OK, MessageBoxImage.Asterisk);
        }

        private void btnUp_Click(object sender, RoutedEventArgs e)
        {
            controls_class.SwapIndexes(-1, listAnswers);
            //can pull recolor option here
            movescount++;
           // MessageBox.Show("yes");

        }
    }
}// end
